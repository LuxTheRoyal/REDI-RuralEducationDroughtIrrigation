2025-07-22 17:04

Status: #Evapourated 

Tags:



# Initial Braindump for REDI

MITES Summer

MITES Semester

LLRISE

RSI

SSP

PROMYS

NASA SEES

CMU SAMS

CMU AI Scholars

CMU CS Scholars

SIMR (Stanford Institutes of Medicine Summer Research Program)

NIH High school Internship Program

John Locke Institute (Princeton, Oxford, Singapore)

LEDA (Leadership Enterprise for a Diverse America)

NSLI-Y (National Security Language Initiative for Youth)

Yale Young Global Scholars

Penn Early Exploration Program (PEEPs)

USC Bovard Scholars

TASS (Telluride Association Summer Seminars)

BU RISE (BU Research in Science & Engineering)

Fly-Ins (matter less, but cool visit, maybe demonstrated interest, maybe [dubious] app boost?)

Dartmouth Bound

Yale in MOHtion

MIT WISE

Caltech Up Close

Columbia STARS

Voices of Tufts



# References
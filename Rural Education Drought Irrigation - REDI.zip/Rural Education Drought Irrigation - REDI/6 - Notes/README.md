2025-07-22 17:03

Status: #Puddle

Tags:



# README

#### Rural Education Drought Irrigation

"This is a GitHub repository to store and organize the Rural Education Drought Irrigation database. The purpose of the database is to REDI ambitious rural students.

We (Alex Bates and Neil Patel) are working on a list of programs that we could give to other kids that are interested. It will include all necessary information for the programs.
I will probably code an API, so the information can easily be navigated.
We are terming it Rural Education Drought Irrigation as a silly way to say we want to spread information to other kids who also lack information about being competitive.
AKA we want to REDI our peers (please laugh).
Currently we are working on converting the database we are building into the note program Obsidian.
It will allow for programs to be searched by pertinent information until it’s to a point that it can be shared with others.
We’re prioritizing programs that are based on merit and are completely paid for if you are accepted (and if they do have application or attendance fees they are either minimal or can be waved with proof of economic situation). 
We hope this will be the most relevant for those we want to reach.

Potential Things to Do
- Database (Find a trajectory with programs and stuff for different plans)
- Tutoring  
- Free Resources
- Club (Student Led, get people to do it at other schools: Chapters is Gamified)
- Scholarships
- FAFSA Tutorial
- Blue Collar Internships (MAC has stuff)
- Fly-ins ig (just for the funsies)

If we cordinate with Mineral Area College in any way, it may be more likely that are school assists REDI."
- Alexander J. T. Bates (07/12/2025)



# References


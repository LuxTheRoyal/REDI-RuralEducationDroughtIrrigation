2025-07-22 16:32

Status: #Evapourated 

Tags: [[Rural Education Drought Irrigation]]



# Status Tags

For a note to move from one tag to another it needs to be proofread and edited. As a note changes tags it is expected to accumulate more references that more strongly tethers it to the [[Rural Education Drought Irrigation]].

The first tag is #Drop which is used for burgeoning notes that are more akin to an idea than a fully fledged note. This tag is a short lived one that is only used as a place holder for a note until more work has been done. This tag can be used to find notes that I made to not forget an idea that I want to fully develop later. 

The second tag is #Puddle which is used for notes that are a work in progress but on their way to completion. Some notes may stay in this state for a long time because there needs to be several references to other notes for a tag promotion.

The third tag is #Stream which is used for kingpin notes that practically serve as directories as they have multiple other notes in their reference section. These notes could indicate key interest clusters or just be broad enough to tie into other notes. This tag could be considered the final stage for a note.

The fourth tag is a rather somber one known as #Evapourated. It is used for archived notes that are no longer being edited for the time being. Notes that have this tag are polished but may represent an idea that has fallen out of favor. 

The fifth and final tag is #Condensed is used to show a rebirth of a previously archived note. A note may switch to this tag to show that I am interested in it again and want to revisit it. This is a transitional tag that is used in between the process of a note being tagged as #Evapourated  and #Stream and as such is meant to be briefly used.



# References